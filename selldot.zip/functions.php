<?php

function dump_var($var) {
    echo '<pre>';
        var_dump($var);
    echo '</pre>';
}

